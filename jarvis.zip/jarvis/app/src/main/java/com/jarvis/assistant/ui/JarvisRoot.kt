package com.jarvis.assistant.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.ui.theme.JarvisColors

/**
 * Базовый корневой экран (Этап 1): чёрный фон и вращающееся ядро.
 * Полный интерфейс (волны, история, настройки, память) делается на Этапе 8.
 */
@Composable
fun JarvisRoot() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisColors.Background)
            .safeDrawingPadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(32.dp)
        ) {
            JarvisCoreBase(Modifier.size(260.dp))
            Text(
                text = "J.A.R.V.I.S.",
                style = MaterialTheme.typography.headlineMedium,
                color = JarvisColors.Cyan
            )
        }
    }
}

@Composable
private fun JarvisCoreBase(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "core")
    val angle = transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(12_000, easing = LinearEasing), RepeatMode.Restart),
        label = "angle"
    )
    val pulse = transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse),
        label = "pulse"
    )

    Canvas(modifier = modifier.rotate(angle.value)) {
        val c = Offset(size.width / 2, size.height / 2)
        val r = size.minDimension / 2
        drawCircle(
            brush = Brush.radialGradient(
                listOf(JarvisColors.Cyan.copy(alpha = 0.55f * pulse.value), JarvisColors.Background),
                center = c, radius = r * 0.7f
            ),
            radius = r * 0.7f, center = c
        )
        drawCircle(JarvisColors.Cyan, radius = r * 0.95f, center = c, style = Stroke(3f))
        drawArc(
            JarvisColors.Blue, startAngle = 0f, sweepAngle = 100f, useCenter = false,
            style = Stroke(10f, cap = StrokeCap.Round)
        )
        drawArc(
            JarvisColors.Cyan, startAngle = 180f, sweepAngle = 60f, useCenter = false,
            style = Stroke(6f, cap = StrokeCap.Round)
        )
        drawCircle(JarvisColors.Cyan.copy(alpha = pulse.value), radius = r * 0.12f, center = c)
    }
}
