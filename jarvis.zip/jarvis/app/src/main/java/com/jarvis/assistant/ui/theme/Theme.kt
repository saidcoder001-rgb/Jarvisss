package com.jarvis.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object JarvisColors {
    val Background = Color(0xFF000000)
    val Surface = Color(0xFF07111A)
    val SurfaceHigh = Color(0xFF0C1C2B)
    val Cyan = Color(0xFF00E5FF)
    val Blue = Color(0xFF2979FF)
    val DeepBlue = Color(0xFF0A3D7A)
    val TextPrimary = Color(0xFFE6F7FF)
    val TextSecondary = Color(0xFF7FA8BF)
    val Danger = Color(0xFFFF5252)
    val Success = Color(0xFF00E676)
}

private val JarvisScheme = darkColorScheme(
    primary = JarvisColors.Cyan,
    onPrimary = Color.Black,
    secondary = JarvisColors.Blue,
    onSecondary = Color.White,
    background = JarvisColors.Background,
    onBackground = JarvisColors.TextPrimary,
    surface = JarvisColors.Surface,
    onSurface = JarvisColors.TextPrimary,
    surfaceVariant = JarvisColors.SurfaceHigh,
    onSurfaceVariant = JarvisColors.TextSecondary,
    error = JarvisColors.Danger,
)

private val JarvisTypography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Light,
        fontSize = 28.sp, letterSpacing = 6.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium,
        fontSize = 16.sp, letterSpacing = 1.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal,
        fontSize = 16.sp, lineHeight = 22.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Normal,
        fontSize = 11.sp, letterSpacing = 2.sp
    ),
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = JarvisScheme,
        typography = JarvisTypography,
        content = content
    )
}
