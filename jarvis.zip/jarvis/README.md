# J.A.R.V.I.S. — персональный голосовой AI-ассистент для Android

Голосовой ассистент на русском языке для Samsung Galaxy S25 Ultra.
Kotlin, Jetpack Compose, Hilt, Room, DataStore, Vosk, Claude API.

## Статус

Готов **Этап 1**: каркас проекта (Gradle, манифест, тема, стартовый экран с ядром).
Не реализовано: голос, AI Brain, контроллеры приложений, память, полный интерфейс (Этапы 2–8).

## Структура

```
jarvis/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/
│   ├── libs.versions.toml          # версии зависимостей
│   └── wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/                    # тема, иконка, строки
        └── java/com/jarvis/assistant/
            ├── JarvisApp.kt
            ├── MainActivity.kt
            └── ui/                 # тема и корневой экран
```

## Как собрать

Нужны Android Studio (последняя стабильная версия) и JDK 17.

1. Распакуйте архив и откройте папку `jarvis` в Android Studio.
2. Дождитесь синхронизации Gradle (файла `gradlew` в архиве нет, студия скачает Gradle 8.9 сама).
3. Подключите телефон с включённой отладкой по USB и нажмите Run.

Версии в `gradle/libs.versions.toml` подобраны без проверки сборки. При ошибках синхронизации поднимите их.

## Планы по этапам

1. Каркас проекта (готово)
2. Голосовой ввод и ответы на русском, слово «Джарвис» (Vosk)
3. AI Brain и tool calling (Claude)
4. Открытие приложений
5. WhatsApp: контакты, черновик, отправка после подтверждения
6. Поиск и передача фотографий
7. Локальная память (Room)
8. Интерфейс в стиле JARVIS
9. Проверка на устройстве

## Безопасность

- API-ключ вводится в настройках и хранится в Android Keystore, не в коде.
- Сообщения, фото и платежи выполняются только после подтверждения пользователя.
- Экран блокировки не обходится.
